import 'package:flutter/material.dart';

void main() => runApp(const Project1App());

class Project1App extends StatelessWidget {
  const Project1App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الإسبانية العالمية',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final stages = ['الصب', 'الخراطة', 'السنفرة', 'النيكل', 'التجميع'];
  final items = <String>['خامة 1', 'خامة 2'];
  final movements = <String>[];

  void addItem() {
    final c = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إضافة صنف'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم الصنف'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              if (c.text.trim().isNotEmpty) {
                setState(() => items.add(c.text.trim()));
              }
              Navigator.pop(context);
            },
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
  }

  void deleteItem(int index) {
    final name = items[index];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد حذف الصنف'),
        content: Text('هل تريد حذف "$name"؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              setState(() => items.removeAt(index));
              Navigator.pop(context);
            },
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  void addMovement(String type) {
    setState(() {
      movements.insert(
        0,
        '$type - ${DateTime.now().toString().substring(0, 16)}',
      );
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تم تسجيل $type')),
    );
  }

  void deleteMovement(int index) {
    final movement = movements[index];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد حذف الحركة'),
        content: Text('هل تريد حذف هذه الحركة؟\n\n$movement'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              setState(() => movements.removeAt(index));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم حذف الحركة')),
              );
            },
            child: const Text('حذف الحركة'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الإسبانية العالمية'),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'إضافة صنف',
              onPressed: addItem,
              icon: const Icon(Icons.add_circle_outline),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'مشروع ١',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text('إدارة التصنيع والمخازن'),
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: () => addMovement('إضافة مخزون'),
                          icon: const Icon(Icons.add),
                          label: const Text('إضافة'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => addMovement('صرف / خصم'),
                          icon: const Icon(Icons.remove),
                          label: const Text('خصم / صرف'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'مراحل التصنيع',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ...stages.asMap().entries.map(
              (e) => Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('${e.key + 1}')),
                  title: Text(e.value),
                  subtitle: const Text('إنتاج • خامات • صرف • تحويل'),
                  trailing: const Icon(Icons.chevron_left),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'الأصناف / الخامات',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ...items.asMap().entries.map(
              (e) => Card(
                child: ListTile(
                  title: Text(e.value),
                  trailing: IconButton(
                    tooltip: 'حذف الصنف',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => deleteItem(e.key),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'سجل الحركات',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                if (movements.isNotEmpty)
                  Text(
                    '${movements.length} حركة',
                    style: const TextStyle(color: Colors.grey),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            if (movements.isEmpty)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.receipt_long),
                  title: Text('لا توجد حركات حتى الآن'),
                ),
              )
            else
              ...movements.asMap().entries.map(
                (e) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.receipt_long),
                    title: Text(e.value),
                    trailing: IconButton(
                      tooltip: 'حذف الحركة',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => deleteMovement(e.key),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 30),
            const Text(
              'هذه نسخة البداية. سيتم لاحقًا ربط قاعدة البيانات وحساب الأرصدة تلقائيًا.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
